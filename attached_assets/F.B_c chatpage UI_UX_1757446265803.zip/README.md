
  # F.B/c chatpage UI/UX

  This is a code bundle for F.B/c chatpage UI/UX. The original project is available at https://www.figma.com/design/OrgpbfU4nSy1xbqtrMyY4i/F.B-c-chatpage-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  