'use client'

import { AILeadGenerationApp } from '@/components/AILeadGenerationApp'

export default function HomePage() {
  return <AILeadGenerationApp />
}