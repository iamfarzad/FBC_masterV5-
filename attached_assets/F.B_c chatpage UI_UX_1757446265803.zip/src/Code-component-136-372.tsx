# PNPM Configuration
auto-install-peers=true
strict-peer-dependencies=false
shamefully-hoist=true
public-hoist-pattern[]=*eslint*
public-hoist-pattern[]=*prettier*
public-hoist-pattern[]=@types/*

# Performance optimizations
prefer-frozen-lockfile=true
engine-strict=true

# Security
audit-level=moderate

# Development
save-exact=true